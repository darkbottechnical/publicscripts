//Everything below needs no changing.
function ww(){
let what=prompt("What's wrong?");
if(what ==="nothing" || what ==="Nothing" || what==="NOTHING"){
alert("Ok then bye have a nice day");
}else{
alert("WHAAAAT");
alert("HOW DARE YOU");
alert("YOU'LL PAY FOR THAT");
window.close();
}
}

function hello(){
var hello=prompt("How's life?");
alert(hello+"? I didn't ask");
alert("BAHAHAHAHA");
}
function exit(){
window.close();
}
function vault(){
var pswd=prompt("Enter a code");
if(pswd==="roll" || pswd==="ra"){
window.open("https://youtube.com/watch?v=dQw4w9WgXcQ", '_blank');
}else if(pswd=="fortnite"){
alert("FORTNITE???");
alert("What's that???");
}else if(pswd==="meg" || pswd==="backrooms"){
window.open("http://backrooms-wiki.wikidot.com/normal-levels-i", '_blank');
}else if(pswd==="69" || pswd==="69420"){
alert("Really...");
}else if(pswd==="educationperfect" || pswd==="ep" || pswd==="EP" || pswd==="Education Perfect" || pswd==="EducationPerfect" || pswd==="education perfect"){
alert("Oh, that pile of garbage?");
window.open("https://www.google.com/search?q=ep&rlz=1C1CHBF_enNZ1040NZ1041&oq=ep&gs_lcrp=EgZjaHJvbWUqDggAEEUYJxg7GIAEGIoFMg4IABBFGCcYOxiABBiKBTIVCAEQLhhDGMcBGLEDGNEDGIAEGIoFMhsIAhAuGEMYxwEYiwMYqAMY0QMY0gMYgAQYigUyDwgDEC4YQxixAxiABBiKBTIPCAQQABhDGIsDGIAEGIoFMhUIBRAuGEMYxwEYsQMY0QMYgAQYigUyDwgGEAAYQxiLAxiABBiKBTIGCAcQRRg90gEIMTcyOWoxajeoAgCwAgA&sourceid=chrome&ie=UTF-8#lrd=0xa82ead528db6e36d:0x471e47f8545323c9,1,,,,", '_blank');
}else if(pswd==="a code"){
alert("Very funny");
var element = document.getElementById("title");
element.classList.add("clch");
}else if(pswd==="911"){
alert("Welcome to the 911 Call center that is definitely not a scam.");
var ch = document.getElementById("bg");
ch.classList.add("bgch");
}else{
alert("That is not a valid code");
}
}
function fun(){
alert("HAHAHAHAHAHAHAHAHAHAHAHA");
intro.textContent = "This is a waffle, made from toilet water and poop powder. Obviously.";
title.textContent = "Waffle =)";
heading.textContent = "Don't worry, you don't need these.";
clickable.textContent = "HAHAHA";
}
function help(){
window.open("guide.html", '_blank')
}